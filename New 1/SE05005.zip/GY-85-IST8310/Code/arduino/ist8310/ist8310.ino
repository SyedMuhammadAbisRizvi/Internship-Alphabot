#include <Wire.h> //I2C Arduino Library

#define address 0x0f // I2C 7bit address of IST8310
                     // I2C 8bit address = 0x1C
void setup(){
  //Initialize Serial and I2C communications
  Serial.begin(9600);
  Wire.begin();

  Wire.beginTransmission(address); //open communication with IST8310
  Wire.write(0x41); //select AVGCNTL register
  Wire.write(0x24); //
  Wire.endTransmission();

  Wire.beginTransmission(address); //open communication with IST8310
  Wire.write(0x42); //select PDCNTL register
  Wire.write(0xC0); //
  Wire.endTransmission();
}

void loop(){
  
  int x,y,z; //triple axis data
   Wire.beginTransmission(address); //open communication with IST8310
   Wire.write(0x0A); //select mode register
   Wire.write(0x01); //SINGLE measurement mode
   Wire.endTransmission();
   delay(6);//6ms

  //Tell the ist8310 where to begin reading data
  Wire.beginTransmission(address);
  Wire.write(0x03); //select register 3, X MSB register
  Wire.endTransmission();
  
 
 //Read data from each axis, 2 registers per axis
  Wire.requestFrom(address, 6);
  if(6<=Wire.available()){
    x = Wire.read(); //X msb
    x |= Wire.read()<<8; //X lsb
    y = Wire.read(); //Y msb
    y |= Wire.read()<<8; //Y lsb
    z = Wire.read(); //Z msb
    z |= Wire.read()<<8; //Z lsb  
  }
  
  //Print out values of each axis
  Serial.print("x: ");
  Serial.print(x);
  Serial.print("  y: ");
  Serial.print(y);
  Serial.print("  z: ");
  Serial.println(z);
  
  delay(10);
}
